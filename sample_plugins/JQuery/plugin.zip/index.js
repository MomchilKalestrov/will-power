import('https://code.jquery.com/jquery-3.7.1.min.js')
	.then(() => console.log('Loaded JQuery!'))
	.catch(() => console.error('Failed to load JQuery'));
